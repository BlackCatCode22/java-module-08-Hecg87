package com.tjavamodule08spr25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TJavaModule08spr25Application {

	public static void main(String[] args) {
		SpringApplication.run(TJavaModule08spr25Application.class, args);
	}

}
